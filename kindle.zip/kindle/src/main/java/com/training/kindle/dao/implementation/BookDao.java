package com.training.kindle.dao.implementation;

import com.training.kindle.dao.IDao;

public class BookDao implements IDao<T> {

}
