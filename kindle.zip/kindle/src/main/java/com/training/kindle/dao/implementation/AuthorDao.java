package com.training.kindle.dao.implementation;

import com.training.kindle.dao.IDao;

public class AuthorDao implements IDao<T> {

}
